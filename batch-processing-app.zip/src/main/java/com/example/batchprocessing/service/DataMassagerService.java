
package com.example.batchprocessing.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class DataMassagerService {

    @Value("${db.batch.size}")
    private int dbBatchSize;

    public List<String> massageData(List<String> records) {
        return records.stream()
                .map(record -> record.replace("old_value", "new_value"))
                .collect(Collectors.toList());
    }
}
