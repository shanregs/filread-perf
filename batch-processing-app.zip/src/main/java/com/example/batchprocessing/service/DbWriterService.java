
package com.example.batchprocessing.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.util.List;

@Service
public class DbWriterService {

    private final JdbcTemplate jdbcTemplate;

    @Value("${db.batch.size}")
    private int dbBatchSize;

    public DbWriterService(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    public void saveBatch(List<String> records) {
        String sql = "INSERT INTO records (data) VALUES (?)";
        jdbcTemplate.batchUpdate(sql, records, dbBatchSize, (ps, record) -> ps.setString(1, record));
    }
}
