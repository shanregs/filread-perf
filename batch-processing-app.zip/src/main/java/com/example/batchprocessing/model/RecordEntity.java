
package com.example.batchprocessing.model;

public class RecordEntity {
    private String data;

    public RecordEntity(String data) {
        this.data = data;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}
